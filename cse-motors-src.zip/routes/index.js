//const baseController = require("../controllers/baseController");

// index route
app.get("/", baseController.buildHome)