//utilities/index.js
const invModel = require("../models/inventory-model")
const Util = {}

/* ************************
 * Constructs the nav HTML unordered list
 ************************** */
Util.getNav = async function (req, res, next) {
  let data = await invModel.getClassifications()
  let list = "<ul>"
  list += '<li><a href="/" title="Home page">Home</a></li>'
  data.rows.forEach((row) => {
    list += "<li>"
    list +=
      '<a href="/inv/type/' +
      row.classification_id +
      '" title="See our inventory of ' +
      row.classification_name +
      ' vehicles">' +
      row.classification_name +
      "</a>"
    list += "</li>"
  })
  list += "</ul>"
  return list
}




/* **************************************
* Build the classification view HTML
* ************************************ */
Util.buildClassificationGrid = async function(data){
  let grid = ''                           // <-- initialize
  if (data.length > 0){
    grid = '<ul id="inv-display">'
    data.forEach(vehicle => { 
      grid += '<li>'
      // absolute paths (no ../../)
      grid += `<a href="/inv/detail/${vehicle.inv_id}" title="View ${vehicle.inv_make} ${vehicle.inv_model} details">
                 <img src="${vehicle.inv_thumbnail}" alt="Image of ${vehicle.inv_make} ${vehicle.inv_model} on CSE Motors" />
               </a>`
      grid += '<div class="namePrice"><hr />'
      grid += `<h2>
                 <a href="/inv/detail/${vehicle.inv_id}" title="View ${vehicle.inv_make} ${vehicle.inv_model} details">
                   ${vehicle.inv_make} ${vehicle.inv_model}
                 </a>
               </h2>`
      grid += `<span>$${new Intl.NumberFormat('en-US').format(vehicle.inv_price)}</span>`
      grid += '</div></li>'
    })
    grid += '</ul>'
  } else { 
    grid = '<p class="notice">Sorry, no matching vehicles could be found.</p>'
  }
  return grid
}


/* Build <select> of classifications (sticky) */
Util.buildClassificationList = async function (classification_id = null) {
  const data = await invModel.getClassifications()
  let select = '<select name="classification_id" id="classificationList" required>'
  select += "<option value=''>Choose a Classification</option>"
  data.rows.forEach(row => {
    select += `<option value="${row.classification_id}"${
      classification_id != null && String(row.classification_id) === String(classification_id)
        ? " selected"
        : ""
    }>${row.classification_name}</option>`
  })
  select += "</select>"
  return select
}



/* ****************************************
 * Middleware For Handling Errors
 * Wrap other function in this for General Error Handling
 **************************************** */

Util.handleErrors = (fn) => (req, res, next) => {
  if (typeof fn !== "function") {
    return next(
      new Error(
        `handleErrors expected a function but got "${typeof fn}" for route ${req.originalUrl}`
      )
    );
  }
  Promise.resolve(fn(req, res, next)).catch(next);
};




module.exports = Util;
